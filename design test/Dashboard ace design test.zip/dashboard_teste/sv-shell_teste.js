/* ============================================================
 * sv-shell_teste.js — injeta a sidebar enterprise + skin em qualquer
 * página do portal. Basta incluir <script src="sv-shell_teste.js"></script>
 * antes de </body>. Não toca no JS/IDs da página.
 * ============================================================ */
(function () {
  // ---- garante skin + fonte ----
  function ensureLink(attrs) {
    var sel = "link[href^='" + attrs.href.split("?")[0] + "']";
    if (document.querySelector(sel)) return;
    var l = document.createElement("link");
    l.rel = attrs.rel || "stylesheet";
    l.href = attrs.href;
    document.head.appendChild(l);
  }
  ensureLink({ href: "sv-skin_teste.css?v=2" });
  ensureLink({ href: "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" });

  var ICON = {
    home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/>',
    users: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-5 6-5s6 1.7 6 5"/><path d="M16 5.2A3 3 0 0 1 16 11"/><path d="M21 20c0-2.6-1.5-4.2-3.8-4.8"/>',
    wallet: '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H18a2 2 0 0 1 2 2v1H5.5"/><path d="M3 7.5V17a2 2 0 0 0 2 2h14a1.5 1.5 0 0 0 1.5-1.5V9.5A1.5 1.5 0 0 0 19 8H4.5"/><circle cx="16.5" cy="13.5" r="1.1"/>',
    layers: '<path d="M12 3 3 7.5l9 4.5 9-4.5L12 3Z"/><path d="M3 12l9 4.5 9-4.5M3 16.5 12 21l9-4.5"/>',
    report: '<rect x="4" y="3" width="16" height="18" rx="2.5"/><path d="M8 13.5v3.5M12 10.5v6.5M16 8v9"/>',
    user: '<circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.6 3-6 7-6s7 2.4 7 6"/>',
    fileText: '<path d="M6 3h8l4 4v14H6V3Z"/><path d="M14 3v4h4"/><path d="M9 12.5h6M9 16h5"/>',
  };
  function svg(name) {
    return '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' + (ICON[name] || "") + "</svg>";
  }

  var GROUPS = [
    { label: "Operação", items: [
      { label: "Dashboard", href: "dashboard_teste.html", icon: "home" },
      { label: "Drivers", href: "driver-profile_teste.html", icon: "users" },
      { label: "Funds", href: "ramp_teste.html", icon: "wallet" },
      { label: "Scope planning", href: "country_scopes_teste.html", icon: "layers" },
    ]},
    { label: "Reports", items: [
      { label: "Payroll", href: "timesheet_teste.html", icon: "report" },
      { label: "Recruitment status", href: "recruitment_teste.html", icon: "user" },
      { label: "Drivers reports", href: "driver-profile_teste.html", icon: "fileText" },
    ]},
  ];

  function mount() {
    if (document.querySelector(".sv-sidebar")) return; // não duplica (ex: dashboard já tem inline)
    var here = (location.pathname.split("/").pop() || "dashboard_teste.html").toLowerCase();
    var activeSet = false;
    var html = '<div class="sv-brand">' +
      '<img class="sv-brand-logo" src="https://aceolution.com/img/logo2.png" alt="Aceolution" onerror="this.outerHTML=\'<div class=&quot;sv-brand-mark&quot;>SV</div>\'">' +
      '<div class="sv-brand-region">Street View · LATAM</div></div><nav class="sv-nav">';
    GROUPS.forEach(function (g) {
      html += '<div class="sv-nav-label">' + g.label + "</div>";
      g.items.forEach(function (it) {
        var isActive = !activeSet && it.href.toLowerCase() === here;
        if (isActive) activeSet = true;
        html += '<a class="sv-nav-item' + (isActive ? " active" : "") + '" href="' + it.href + '">' +
          '<span class="sv-ico">' + svg(it.icon) + "</span><span>" + it.label + "</span></a>";
      });
    });
    html += "</nav><div class=\"sv-foot\"><div class=\"sv-foot-dot\"></div><div>" +
      '<div class="sv-foot-l1">Apps Script · live</div><div class="sv-foot-l2">v5.21 · build 2026.06</div></div></div>';

    var aside = document.createElement("aside");
    aside.className = "sv-sidebar";
    aside.innerHTML = html;
    document.body.appendChild(aside);
    document.body.classList.add("sv-shell");
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
})();
